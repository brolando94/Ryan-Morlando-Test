﻿namespace MusicLibrary.Models
{
    public class Album:Artist
    {
        //id and name for album derived from artist.. add artist 
        public string Artist { get; set; }  

    }
}
