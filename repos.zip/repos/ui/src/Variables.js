export const variables={
    API_URL:"http://localhost:63560/api/"
}