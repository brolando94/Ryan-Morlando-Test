import React,{Component} from 'react';

export class Home extends Component{
    render(){
        return(
            <div>
                <h3>The Home Page</h3>
            </div>
        )
    }
}
